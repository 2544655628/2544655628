//试除法求因数
#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
 
using namespace std;
 
vector<int> get_divisors(int n)
{
    vector <int> res;
    for(int i = 1;i <= n / i; i ++)
    {
        if(n % i == 0){
            res.push_back(i);
            if(i != n / i) res.push_back(n/i);
        }
    }
    sort(res.begin(),res.end());
    return res;
}
int main()
{
    int n;
    cin >> n;
    while(n --)
    {
        int x;
        cin >> x;
        vector <int> res;
        res = get_divisors(x);
        for(auto c : res)
        {
            cout << c << " ";
        }
        cout << endl;
            
    
    }
}

//求因数个数
#include <iostream>
#include <cstring>
#include <algorithm>
#include <unordered_map>
const int mod = 1e9 + 7;
typedef long long LL;
using namespace std;
int main()
{
    unordered_map <int,int> primes;
    int n;
    cin >> n;
    while (n -- )
    {
        int x;
        cin >> x;
        for(int i = 2;i <= x / i;i ++)
        {
            while(x % i == 0)
            {
                x /= i;
                primes[i] ++;
            }
            
        }
        if(x > 1) primes[x] ++;
    }
    
    LL res = 1;
    for(auto c: primes)
    {
        res  = res * (c.second + 1) % mod;
    }
    cout << res << endl;
}

//求因数之和
#include <bits/stdc++.h>
typedef long long LL;
const int mod = 1e9 + 7;
using namespace std;
int main()
{
    unordered_map<int,int> primes;   //一个值存的是这个质因数，第二个存的是指数
    int n;
    cin >>n;
    while (n -- )
    {
        int x;
        cin >> x;
        for(int i = 2;i <= x / i;i ++)
        {
            while(x % i == 0) 
            {
               x /= i;
               primes[i] ++ ;   // 指数加一
            }
        
        }
        if(x > 1) primes[x] ++;
    }
    LL res = 1;
    for(auto c : primes)
    {
        int a = c.first,b = c.second;
        LL t = 1;
        while(b--)  t = (t * a + 1) % mod;
        res = res * t % mod;
    }
    cout << res << endl;
}