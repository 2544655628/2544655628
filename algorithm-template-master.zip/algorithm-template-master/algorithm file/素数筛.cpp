#include<bits/stdc++.h>

using namespace std;

#define int long long
const int N = 20000000;
vector<bool>isprime(N+1);
int a[N] = {0};

void solve()
{
    unsigned long long n;
    cin >> n;
    int cnt = 0;
    for(int i = 2; i <= N; i++)
    {
    	if(!isprime[i])
    		a[++cnt] = i;
    	for(int j = 1; j <= cnt, i*a[j] <= N; j++)
    	{
    		isprime[i*a[j]] = true;
    		if(!(i%a[j]))break;//
    	}
    }
    for(int i = 1; i <= cnt; ++i)
    {
    	cout << a[i] << " "; 
    }
}

signed main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int t = 1;
	//cin >> t;
	while(t--)solve();
	return 0;
}