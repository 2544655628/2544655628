#include <bits/stdc++.h>

using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	string main, sub;
	cin >> main;
	cin >> sub;
	int nextval[sub.size()];
	int k = 0, i = 1, cnt = 0;
	memset(nextval, 0, sizeof(nextval));
	while (i != sub.size()) {
		//        cout << i << endl;
		//        cout << k << ' ' << i << " " << nextval[i] << endl;
		if (sub[k] == sub[i]) {
			//            cout << i << endl;
			cnt++;
			nextval[i] = cnt > nextval[i] ? cnt : nextval[i];
			//            cout << nextval[i] << endl;
			k++;
			i++;
		} else if (k > 0 && nextval[k - 1] == 0) {
			nextval[i] = 0;
			k = 0;
			cnt = 0;
		} else if (k > 0 && nextval[k - 1] != 0) {

			//            cout << i << "=" << nextval[k - 1] << endl;
			cnt = nextval[k - 1];
			k = nextval[k - 1];

		} else {
			nextval[i] = 0;
			i++;
		}
	}
	for (auto p: nextval)cout << p << " ";

	

	k = 0, i = 0;
	while (k < main.size()) {
		if (main[k] == sub[i]) {
			k++;
			i++;
		} else if (i > 0) {
			i = nextval[i - 1];
		} else {
			i++;
		}
		if (i == sub.size()) {
			cout<<"子串位于"<<k-i;
		}
	}
	return 0;
}
