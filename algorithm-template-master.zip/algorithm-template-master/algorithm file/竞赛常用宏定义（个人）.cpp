#include<bits/stdc++.h>

#define ll long long
#define endl '\n'
#define IOS ios::sync_with_stdio(false)
#define tn cin.tie(nullptr);cout.tie(nullptr);
#define de(a) for(const auto & p : a )cout<<p<<" ";cout<<endl;
#define c(a) cout<<#a<<" = "<<a<<endl;
#define max(a) max_element(a.begin(),a.end())
#define min(a) min_element(a.begin(),a.end())
#define dis(a, b) abs(distance(a,b))

using namespace std;

void solve()
{
    //AC代码
}

int main() {
    IOS;
    tn;
    int q = 1;
    cin >> q;
    cout << q;
    while (q--) {
        solve();
    }
    return 0;
}

