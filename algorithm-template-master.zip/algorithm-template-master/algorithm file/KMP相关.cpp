//字符串查找（KMP）

//1.正向查找find（）
//1.1  s.find（str）
//string中find()返回值是字母在母串中的下标位置。
//如果没有找到，那么会返回一个特别的标记npos，一般写作string::npos。

string s, c;
int main() {
  s = "apple";
  c = "l";
  int index = s.find(c);
  if (index != string::npos)
    cout << index << endl;
}
//结果返回下标

//1.2  s.find（str，pos）
//find(str,pos)是用来寻找从pos开始(包括pos处字符)匹配str的位置。

string s, c;
int main() {
  s = "laaaal";
  c = "l";
  int index = s.find(c,3);//从字符串s下标3的位置开始寻找
  if (index != string::npos)
  cout << index << endl;
}
//结果返回下标

//1.3 s.find_first_of（str） 和 s.find_last_of（str）
//找到目标字符在字符串中第一次出现和最后一次出现的位置

string s, c;
int main() {
  s = "laaaal";
  c = "l";
  cout << "first index:" << s.find_first_of(c) << endl;
  cout << "last index:" << s.find_last_of(c) << endl;
}
//结果返回下标


//1.4查找目标字符串在字符串出现的总次数（不重复）
//核心代码：index=s.find(c,index)，index每次都会更新下一次找到的位置，如果没有找到跳出循环。

string s, c;

int main() {
  while (cin >> s >> c) {
    int index = 0;//用来存储不断更新最新找到的位置
    int sum = 0;//累加出现的次数
    while ((index = s.find(c,index)) != string::npos) {
      cout << "sum: " << sum+1 << " index: " << index <<endl;
      index += c.length();//上一次s中与c完全匹配的字符应跳过，不再比较
      sum++;
    }
    cout << "sum=" << sum << endl;
  }
}

//输入：
//llllll
//ll
//输出：
//sum: 1 index: 0
//sum: 2 index: 2
//sum: 3 index: 4
//sum=3


//1.5 逆向查找rfind（）
s.rfind(str)： 是从字符串右侧开始匹配str，并返回在字符串中的下标位置；
string s = "apple";
cout << s.rfind("l") << endl;

rfind(str，pos); //从pos开始，向前查找符合条件的字符串；
//结果返回下标
