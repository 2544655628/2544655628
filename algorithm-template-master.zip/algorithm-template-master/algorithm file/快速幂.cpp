//取模版本
long long Mod=1e9+7;
long long fastPower(long long base, long long power) {
    long long result = 1;
    while (power > 0) {
        if (power & 1) {
            result = result * base % Mod;
        }
        power = power / 2;
        base = (base * base) % Mod;
    }
    return result;
}

//不取模版本
#include <iostream>
using namespace std;

long long fun (long long x,long long y)
{
    if(y==0)return 1;
    if(y==1)return x;
    if(y&1)return fun(x*x,(y)/2)*x;
    return fun(x*x,y/2);
}

int main()
{
    int a,b;cin>>a>>b;
    cout<<fun(a,b);
}