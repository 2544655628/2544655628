//高精度加法
#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <cmath>

using namespace std;

const int N = 1e5 + 10;
int a[N],b[N],c[N];//数组C存储结果
char s1[N],s2[N];//存储读入的字符串

int main()
{
    cin >> s1 >> s2;
    int la = strlen(s1);
    int lb = strlen(s2);
    for (int i = 0;i < la;i++) a[la - i] = s1[i] - '0';//倒序存储
    for (int i = 0;i < lb;i++) b[lb - i] = s2[i] - '0';
    int lc = max(la,lb) + 1;
    for (int i = 1;i <= lc;i++)//注意此处的下标从1开始(可以使用12345 + 23456模拟)
    {
        c[i] += (a[i] + b[i]);//两式相加
        c[i + 1] = c[i] / 10;//如果有进位的话,向高位进位
        c[i] = c[i] % 10;//如果是两位数,则进位之后需要取模
    }
    //删除前导0
    if (c[lc] == 0) lc --;
    for (int i = lc;i > 0;i --) printf("%d",c[i]);
    return 0;
}


//高精度减法

#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>

using namespace std;

const int N = 1e5 +10;
int a[N],b[N],c[N];//数组c用来存储结果
char s1[N],s2[N],s3[N];//s3用来帮助交换s1和s2
int flag;//默认为0

//判断s1和s2的大小关系:如果s1 >= s2,返回true;否则,返回false
bool cmp(char s1[],char s2[])
{
    int u = strlen(s1),v = strlen(s2);
    if (u != v) return u > v;
    
    for (int i = 0;i < u;i++)//执行到这里,说明u == v
        if (s1[i] != s2[i])
            return s1[i] > s2[i];
    return true;//s1 == s2
}

int main()
{
    int la,lb,lc; cin >> s1 >> s2;
    if (!cmp(s1,s2))//表示s1 < s2
    {
        //交换之后可以保证s1 > s2
        flag = 1;
        strcpy(s3,s1);
        strcpy(s1,s2);
        strcpy(s2,s3);
    }
    la = strlen(s1),lb = strlen(s2);
    
    //将输入的字符串转化为数字并倒序存储
    for (int i = 0;i < la;i++) a[la - i] = s1[i] - '0';
    for (int i = 0;i < lb;i++) b[lb - i] = s2[i] - '0';
    
    //高精度算法核心代码
    lc = max(la,lb);
    for (int i = 1;i <= lc;i++)
    {
        if (a[i] < b[i])
        {
            a[i + 1] --;//借位
            a[i] += 10;
        }
        c[i] = a[i] - b[i];
    }
    
    while (c[lc] == 0 && lc > 1) lc --;//删除前导0
    if (flag == 1) cout << "-";
    for (int i = lc;i > 0;i--) cout << c[i];
    return 0;
}


//高精度乘法

#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>

using namespace std;
const int N = 1e5 + 10;
int a[N],b[N],c[N];//c数组用来保存结果
char s1[N],s2[N];

int main()
{
    cin >> s1 >> s2;//输入数据
    int la = strlen(s1),lb = strlen(s2);
    
    for (int i = 0;i < la;i++) a[la - i] = s1[i] - '0';//转化为数字再逆序存储
    for (int i = 0;i < lb;i++) b[lb - i] = s2[i] - '0';

    int lc = la + lb;    
    for (int i = 1;i <= la;i++)//高精度算法核心代码
    {
        for (int j = 1;j <= lb;j++)
        {
            c[i + j - 1] += (a[i] * b[j]);//计算
            c[i + j] += c[i + j - 1] / 10;//向高位进位
            c[i + j - 1] %= 10;
        }
    }
        
    while (c[lc] == 0 && lc > 1) lc --;//删除前导0
    for (int i = lc;i > 0;i--) cout << c[i];//输出结果
    return 0;
}